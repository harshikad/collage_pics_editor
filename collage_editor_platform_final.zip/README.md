#  College Editor Platform – Image Collage Builder (Django)

A web platform built with Django that allows users to:
- Sign up / Log in
- Upload up to 10 images
- Automatically generate a responsive image collage
- Rearrange images with drag-and-drop
- Download the final collage
- Choose custom grid layout (2x2, 3x3, etc.)

---

##  Features

- User Authentication (Sign up / Login / Logout)
- Upload multiple images (max 10)
- Select grid layout style (e.g., 2x2, 3x3)
- Drag-and-drop to reorder images
- Live image preview
- Download generated collage as one image
- Mobile responsive design
- TailwindCSS-powered frontend

---

##  Technologies Used

- **Backend:** Django (Python)
- **Frontend:** HTML, CSS, JavaScript, Tailwind CSS
- **Database:** SQLite
- **Image Handling:** Pillow

---

##  Setup Instructions

1. **Clone the repository**
   ```bash
   git clone https://github.com/your-username/college-editor-platform.git
   cd college-editor-platform

2. **Create a virtual environment**
    ```bash
    python -m venv venv
    venv\Scripts\activate   # On Windows

3. **Install dependencies**
    ```bash
    pip install -r requirements.txt
    
4. **Run migrations**
    ```bash
    python manage.py makemigrations
    python manage.py migrate
5. **Start the server**
    ```bash
    python manage.py runserver
6. **Visit the app**
Open your browser and go to: http://127.0.0.1:8000/