from django.shortcuts import render, redirect, get_object_or_404
from .forms import CollageForm, SignUpForm
from .models import Collage, ImageItem
from django.http import JsonResponse, HttpResponse
from django.views.decorators.csrf import csrf_exempt
from django.contrib.auth import login, logout
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth.decorators import login_required
import json
import zipfile
import io

@login_required
def collage_list(request):
    form = CollageForm()
    uploaded_images = None
    collage = None
    if request.method == "POST":
        form = CollageForm(request.POST, request.FILES)
        images = request.FILES.getlist('images')
        if form.is_valid():
            if len(images) > 10:
                form.add_error(None, "You can upload a maximum of 10 images.")
            else:
                collage = form.save(commit=False)
                collage.user = request.user
                collage.save()
                for image in images:
                    ImageItem.objects.create(collage=collage, image=image)
                uploaded_images = collage.images.all()
                # Instead of redirect, render the same page with previews and download
                return render(request, 'collage_app/collage_list.html', {
                    'collages': Collage.objects.filter(user=request.user).order_by('-created_at'),
                    'form': CollageForm(),
                    'uploaded_images': uploaded_images,
                    'collage': collage,
                })
    collages = Collage.objects.filter(user=request.user).order_by('-created_at')
    return render(request, 'collage_app/collage_list.html', {
        'collages': collages,
        'form': form
    })
@login_required
def collage_detail(request, collage_id):
    collage = get_object_or_404(Collage, id=collage_id)
    images = collage.images.order_by('position')
    return render(request, 'collage_app/collage_detail.html', {
        'collage': collage,
        'images': images
    })

@login_required
def upload_collage(request):
    if request.method == 'POST':
        form = CollageForm(request.POST)
        images = request.FILES.getlist('images')
        if form.is_valid() and images:
            collage = form.save(commit=False)
            collage.user = request.user
            collage.save()
            for image in images:
                ImageItem.objects.create(collage=collage, image=image)
            # Fetch images just uploaded
            uploaded_images = collage.images.all()
            return render(request, 'collage_app/upload.html', {
                'form': CollageForm(),
                'uploaded_images': uploaded_images,
                'collage': collage,
                'show_sample': True
            })
    else:
        form = CollageForm()
    return render(request, 'collage_app/upload.html', {'form': form})

@login_required
def edit_collage(request, collage_id):
    collage = get_object_or_404(Collage, id=collage_id)
    images = collage.images.all()
    if request.method == 'POST':
        new_images = request.FILES.getlist('images')
        total_images = images.count() + len(new_images)
        if total_images > 10:
            return render(request, 'collage_app/edit_collage.html', {
                'collage': collage,
                'images': images,
                'error': "You can only have up to 10 images in total."
            })
        for img in new_images:
            ImageItem.objects.create(collage=collage, image=img)
        return redirect('collage_detail', collage_id=collage.id)
    return render(request, 'collage_app/edit_collage.html', {
        'collage': collage,
        'images': images
    })

@login_required
def delete_collage(request, collage_id):
    collage = get_object_or_404(Collage, id=collage_id)
    if request.method == 'POST':
        collage.delete()
        return redirect('collage_list')
    return redirect('collage_detail', collage_id=collage.id)

@login_required
def delete_image(request, image_id):
    image = get_object_or_404(ImageItem, id=image_id)
    collage_id = image.collage.id
    image.delete()
    return redirect('collage_detail', collage_id=collage_id)

@login_required
@csrf_exempt
def reorder_images(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            for item in data.get('order', []):
                image_id = item['id']
                new_position = item['position']
                ImageItem.objects.filter(id=image_id).update(position=new_position)
            return JsonResponse({'status': 'success'})
        except Exception as e:
            return JsonResponse({'status': 'error', 'message': str(e)}, status=400)
    return JsonResponse({'status': 'invalid method'}, status=405)

def signup_view(request):
    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('collage_list')
    else:
        form = SignUpForm()
    return render(request, 'collage_app/signup.html', {'form': form})

def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('collage_list')
    else:
        form = AuthenticationForm()
    return render(request, 'collage_app/login.html', {'form': form})

@login_required
def logout_view(request):
    logout(request)
    return redirect('login')

@login_required
def download_collage(request, collage_id):
    collage = Collage.objects.get(id=collage_id)
    images = collage.images.all()
    zip_buffer = io.BytesIO()
    with zipfile.ZipFile(zip_buffer, "w") as zip_file:
        for img in images:
            zip_file.write(img.image.path, img.image.name.split('/')[-1])
    zip_buffer.seek(0)
    response = HttpResponse(zip_buffer, content_type='application/zip')
    response['Content-Disposition'] = f'attachment; filename=collage_{collage.id}.zip'
    return response
