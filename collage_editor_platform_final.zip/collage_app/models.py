from django.db import models
from django.contrib.auth.models import User

class Collage(models.Model):
    LAYOUT_CHOICES = [
        ('2x2', '2 x 2'),
        ('3x3', '3 x 3'),
        ('4x4', '4 x 4'),
    ]

    title = models.CharField(max_length=100)
    layout = models.CharField(max_length=10, choices=LAYOUT_CHOICES, default='3x3')
    created_at = models.DateTimeField(auto_now_add=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE)

    def __str__(self):
        return self.title


class ImageItem(models.Model):
    collage = models.ForeignKey(Collage, on_delete=models.CASCADE, related_name='images')
    image = models.ImageField(upload_to='image_item/')
    position = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ['position']

    def __str__(self):
        return f"Image for {self.collage.title}"
