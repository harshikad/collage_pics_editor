from django.urls import path
from . import views

urlpatterns = [
    path('', views.upload_collage, name='upload_collage'),
    path('collages/', views.collage_list, name='collage_list'),
    path('collages/<int:collage_id>/', views.collage_detail, name='collage_detail'),
    path('collages/<int:collage_id>/delete/', views.delete_collage, name='delete_collage'),
    path('collages/<int:collage_id>/edit/', views.edit_collage, name='edit_collage'),
    path('image/<int:image_id>/delete/', views.delete_image, name='delete_image'),
    path('reorder-images/', views.reorder_images, name='reorder_images'),
    path('signup/', views.signup_view, name='signup'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('collages/<int:collage_id>/download/', views.download_collage, name='download_collage'),
    path('upload/', views.upload_collage, name='upload_collage'),
    path('download/<int:collage_id>/', views.download_collage, name='download_collage'),
]
