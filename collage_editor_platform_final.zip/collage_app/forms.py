from django import forms
from .models import Collage
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

class CollageForm(forms.ModelForm):
    class Meta:
        model = Collage
        fields = ['title', 'layout']

class SignUpForm(UserCreationForm):
    email = forms.EmailField(required=True)
    class Meta:
        model = User
        fields = ('username', 'email', 'password1', 'password2')
