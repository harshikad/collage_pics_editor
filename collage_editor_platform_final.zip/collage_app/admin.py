from django.contrib import admin
from .models import Collage, ImageItem

admin.site.register(Collage)
admin.site.register(ImageItem)
